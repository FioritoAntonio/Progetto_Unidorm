from flask import Flask, render_template, request, redirect, url_for, session, jsonify,json
from datetime import datetime
from werkzeug.utils import secure_filename
import sqlite3
import os


# Creazione dell'app Flask
app = Flask(__name__)

# Aggiunta della chiave segreta per la gestione delle sessioni
app.secret_key = 'SitoWeb'

DATABASE = 'unidorm.db'

UPLOAD_FOLDER = 'static/images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # Limite: 16 MB

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


# Funzione per connettersi al database SQLite
def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


# Funzione per inizializzare il database e creare le tabelle
def init_db():
    if not os.path.exists(DATABASE):
        with get_db() as db:
            # Creazione delle tabelle necessarie
            db.execute('''CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cognome TEXT NOT NULL,
                data_nascita DATE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                ruolo TEXT NOT NULL,
                matricola TEXT,
                universita TEXT,
                corso_laurea TEXT
            )''')
            db.execute('''CREATE TABLE IF NOT EXISTS annuncio (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            utente_id INTEGER NOT NULL,
                            titolo TEXT NOT NULL,
                            tipologia TEXT NOT NULL,
                            descrizione TEXT NOT NULL,
                            citta TEXT NOT NULL,
                            indirizzo TEXT NOT NULL,
                            prezzo INTEGER NOT NULL,
                            posti INTEGER NOT NULL,
                            servizi TEXT,
                            telefono TEXT,
                            email TEXT,
                            disponibilita_inizio DATE,
                            disponibilita_fine DATE,
                            FOREIGN KEY (utente_id) REFERENCES users (id)
                        )''')

            db.execute('''CREATE TABLE IF NOT EXISTS prenotazioni (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            utente_id INTEGER NOT NULL,
                            annuncio_id INTEGER NOT NULL,
                            data_inizio DATE NOT NULL,
                            data_fine DATE NOT NULL,
                            numero_ospiti INTEGER NOT NULL,
                            note TEXT,
                            FOREIGN KEY (utente_id) REFERENCES users (id),
                            FOREIGN KEY (annuncio_id) REFERENCES annuncio (id)
                        )''')

            db.execute('''CREATE TABLE IF NOT EXISTS immagine_annuncio (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            annuncio_id INTEGER NOT NULL,
                            url TEXT NOT NULL,
                            FOREIGN KEY (annuncio_id) REFERENCES annuncio(id) ON DELETE CASCADE
                        )''')

            db.execute('''
                                   CREATE TABLE IF NOT EXISTS segnalazioni (
                                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                                       annuncio_id INTEGER NOT NULL,
                                       segnalatore_id INTEGER NOT NULL,
                                       motivazione TEXT NOT NULL,
                                       data_segnalazione TIMESTAMP NOT NULL,
                                       letta BOOLEAN NOT NULL DEFAULT 0,
                                       FOREIGN KEY (annuncio_id) REFERENCES annuncio(id),
                                       FOREIGN KEY (segnalatore_id) REFERENCES users(id)
                                   )
                               ''')

            # Crea la tabella notifiche
            db.execute('''
                                   CREATE TABLE IF NOT EXISTS notifiche (
                                       id INTEGER PRIMARY KEY AUTOINCREMENT,
                                       user_id INTEGER NOT NULL,
                                       tipo TEXT NOT NULL,
                                       contenuto TEXT NOT NULL,
                                       data_creazione TIMESTAMP NOT NULL,
                                       FOREIGN KEY (user_id) REFERENCES users(id)
                                   )
                   ''')

            print("Database e tabelle creati con successo!")






# Route per la homePage
@app.route('/Pagina', methods=['GET', 'POST'])
def home():
    # Recupera gli annunci pubblicati dall'utente
    with get_db() as db:
        # Ottieni tutti gli annunci
        annunci = db.execute("SELECT * FROM annuncio").fetchall()

        # Prepara una lista di annunci con immagini
        annunci_completi = []
        for annuncio in annunci:
            annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario

            # Recupera le immagini associate all'annuncio
            immagini = db.execute('''
                SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
            ''', (annuncio['id'],)).fetchall()

            # Aggiungi le immagini alla struttura dell'annuncio
            annuncio_dict['immagini'] = [dict(img) for img in immagini]  # Converti anche le immagini in dizionari
            annunci_completi.append(annuncio_dict)

    # Passa gli annunci alla pagina 'Pagina.html'
    return render_template('Pagina.html', annunci=annunci_completi)


# Route per la pagina di pubblicazione annuncio
@app.route('/pubblica-annuncio', methods=['GET', 'POST'])
def pubblica_annuncio():
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    if request.method == 'POST':
        return redirect(url_for('Pagina_logged'))  # Redirect dopo la pubblicazione

    return render_template('Pubblica_annuncio.html', iniziali=iniziali)

# Route per pubblicare l'annuncio nel database
@app.route('/pubblica_ann', methods=['GET', 'POST'])
def pubblica_ann():
    if request.method == 'POST':
        try:
            # Recupera i dati dal form
            titolo = request.form.get('titolo')
            tipologia = request.form.get('tipologia')
            descrizione = request.form.get('descrizione')
            citta = request.form.get('citta')
            indirizzo = request.form.get('indirizzo')
            prezzo = request.form.get('prezzo')
            posti = request.form.get('posti')
            servizi = ','.join(request.form.getlist('servizi'))  # Unisci i servizi in una stringa
            telefono = request.form.get('telefono')
            email = request.form.get('email')
            utente_id = session.get('user_id')
            disponibilita_inizio = request.form['disponibilita_inizio']
            disponibilita_fine = request.form['disponibilita_fine']

            # Assicurati che le date siano nel formato corretto
            disponibilita_inizio = datetime.strptime(disponibilita_inizio, '%Y-%m-%d').strftime('%Y-%m-%d')
            disponibilita_fine = datetime.strptime(disponibilita_fine, '%Y-%m-%d').strftime('%Y-%m-%d')

            # Salva i dati nel database per l'annuncio
            with get_db() as db:
                cursor = db.cursor()
                cursor.execute('''INSERT INTO annuncio (utente_id, titolo, tipologia, descrizione, citta, indirizzo, prezzo, posti, servizi, telefono, email, disponibilita_inizio, disponibilita_fine)
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                               (utente_id, titolo, tipologia, descrizione, citta, indirizzo, prezzo, posti, servizi,
                                telefono, email, disponibilita_inizio, disponibilita_fine))
                db.commit()  # Effettua il commit subito dopo l'inserimento

                # Ottieni l'ID dell'annuncio appena creato
                cursor.execute('SELECT last_insert_rowid()')
                annuncio_id = cursor.fetchone()[0]
                print(f"ID dell'annuncio: {annuncio_id}")  # Verifica se l'ID è corretto

                # Gestione del caricamento delle immagini
                if 'images' in request.files:
                    images = request.files.getlist('images')
                    if len(images) > 7:
                        return "Puoi caricare al massimo 7 immagini", 400
            for image in images:
                if image and allowed_file(image.filename):
                    filename = secure_filename(image.filename)

                    # Percorso relativo per l'immagine (dentro la cartella 'static/images')
                    image_url = os.path.join('images', filename)  # Questo percorso sarà relativo alla cartella static

                    filepath = os.path.join(UPLOAD_FOLDER, filename)  # Percorso assoluto per il salvataggio del file

                    # Salva il file fisicamente
                    image.save(filepath)

                    # Salva solo il percorso relativo nel database
                    with get_db() as db:
                        db.execute('''INSERT INTO immagine_annuncio (annuncio_id, url) VALUES (?, ?)''',
                                   (annuncio_id, image_url))
                        db.commit()

            # Reindirizza alla lista degli annunci
            return redirect(url_for('miei_annunci'))

        except Exception as e:
            print(f"Errore durante la pubblicazione dell'annuncio: {e}")
            return "Errore durante la pubblicazione dell'annuncio. Riprova."

    return render_template('Pubblica_annuncio.html')  # Ritorna il form se GET



@app.route('/registrazione-host', methods=['GET', 'POST'])
def register_host():
    if request.method == 'GET':
        return render_template('registrazione.html')

    if request.method == 'POST':
        data = request.get_json()  # Usa get_json per ottenere i dati inviati come JSON

        # Verifica che tutti i campi siano presenti
        required_fields = ['nome', 'cognome', 'dataNascita', 'email', 'password']
        for field in required_fields:
            if not data.get(field):
                return jsonify({"message": f"Campo {field} mancante o vuoto"}), 400

        # Connessione al database e salvataggio
        try:
            conn = sqlite3.connect('unidorm.db')
            cursor = conn.cursor()

            cursor.execute('SELECT * FROM users WHERE email = ?', (data['email'],))
            existing_user = cursor.fetchone()

            if existing_user:
                return jsonify({"message": "L'email è già registrata."}), 400

            cursor.execute('''INSERT INTO users (nome, cognome, email, password, ruolo, data_nascita)
                             VALUES (?, ?, ?, ?, ?, ?)''',
                           (data['nome'], data['cognome'], data['email'], data['password'], 'host', data['dataNascita']))
            conn.commit()

            return jsonify({"message": "Registrazione completata con successo!"}), 200
        except Exception as e:
            conn.rollback()
            return jsonify({"message": f"Errore nel salvataggio: {str(e)}"}), 500
        finally:
            conn.close()



# Nel tuo file Python, semplifica la route:
@app.route('/registrazione-studente', methods=['GET', 'POST'])
def registrazione_studente():
    if request.method == 'GET':
        # Renderizza il template HTML per il form di registrazione
        return render_template('registrazione-studente.html')

    if request.method == 'POST':
        try:
            # Ricevi i dati JSON dal frontend
            dati_studente = request.get_json()

            # Logga i dati per il debug
            print("Dati ricevuti dal frontend:", dati_studente)

            # Verifica se l'email e la data di nascita sono presenti
            if 'email' not in dati_studente:
                raise ValueError("Email non fornita")
            if 'data_nascita' not in dati_studente:
                raise ValueError("Data di nascita non fornita")

            # Salva i dati nel database
            with get_db() as conn:
                conn.execute('''
                    INSERT INTO users (nome, cognome, matricola, universita, email, password, ruolo, corso_laurea, data_nascita) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                             (dati_studente['nome'], dati_studente['cognome'],
                              dati_studente['matricola'], dati_studente['universita'],
                              dati_studente['email'], dati_studente['password'],
                              'studente', dati_studente['corso_laurea'], dati_studente['data_nascita']))
                conn.commit()

            return jsonify({"success": True, "message": "Registrazione completata con successo!"})


        except Exception as e:
            return jsonify({"success": False, "message": str(e)}), 500




# Route per il login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        with get_db() as db:
            # Confronto diretto password in chiaro
            user = db.execute('SELECT * FROM users WHERE email = ? AND password = ?', (email, password)).fetchone()

            if user is None:
                # Passa il messaggio di errore al template
                return render_template('accedi.html', error="Email o password errati.")

            if user:
                # Salva i dati dell'utente nella sessione
                session['nome'] = user['nome']
                session['cognome'] = user['cognome']
                session['user_id'] = user['id']
                session['ruolo'] = user['ruolo']

                # Controlla il ruolo dell'utente
                if user['ruolo'] == 'admin':
                    return redirect(url_for('admin'))
                elif user['ruolo'] == 'studente':  # Aggiunto il controllo per il ruolo "studente"
                    return redirect(url_for('studenti_logged'))  # Reindirizza alla pagina studenti_logged
                else:
                    return redirect(url_for('home_logged'))
            else:
                # Se l'utente non esiste, rimanda al login
                return redirect(url_for('login'))

    return render_template('accedi.html')


@app.route('/home_logged')
def home_logged():
    # Recupera nome e cognome dalla sessione
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    # Recupera gli annunci pubblicati dall'utente
    with get_db() as db:
        # Ottieni tutti gli annunci
        annunci = db.execute("SELECT * FROM annuncio").fetchall()

        # Prepara una lista di annunci con immagini
        annunci_completi = []
        for annuncio in annunci:
            annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario
            immagine = db.execute('''
                    SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
                ''', (annuncio['id'],)).fetchall()
            annuncio_dict['immagini'] = immagine

            annunci_completi.append(annuncio_dict)
            print(annunci_completi)


    # Mostra la pagina iniziale con i dati dell'utente
    if nome and cognome:
        return render_template('Pagina_logged.html', iniziali=iniziali, annunci=annunci_completi)
    else:
        return redirect(url_for('login'))

# Route per passare alla modalità studente
@app.route('/modalita-studente', methods=['GET', 'POST'])
def modalita_studente():
    user_id = session.get('user_id')  # Prendi l'ID utente dalla sessione

    if not user_id:  # Se l'utente non è loggato, lo rimandi al login
        return redirect(url_for('login'))

    # Verifica se l'utente ha le informazioni necessarie
    with get_db() as db:
        user = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()

    if user and user['matricola'] and user['universita'] and user['corso_laurea']:
        # Se l'utente ha tutte le informazioni necessarie, reindirizza alla pagina studenti_logged
        return redirect(url_for('studenti_logged'))
    else:
        # Altrimenti, reindirizza alla pagina per aggiungere le informazioni
        return redirect(url_for('aggiungi_informazioni'))


@app.route('/aggiungi-informazioni', methods=['GET', 'POST'])
def aggiungi_informazioni():
    utente_id = session.get('user_id')

    if not utente_id:
        return redirect(url_for('login'))  # Se non loggato, reindirizza al login

    if request.method == 'GET':
        return render_template('aggiungi_informazioni.html')

    if request.method == 'POST':
        try:
            # Recupera i dati inviati dal client
            dati_studente = request.get_json()
            print("Dati ricevuti:", dati_studente)

            # Aggiorna le informazioni dello studente nel database
            with get_db() as conn:
                conn.execute('''
                    UPDATE users 
                    SET matricola = ?, corso_laurea = ?, universita = ?, ruolo = ?
                    WHERE id = ?
                ''', (
                    dati_studente['matricola'],
                    dati_studente['corso_laurea'],
                    dati_studente['universita'],
                    'studente',
                    utente_id  # Corretto: usa direttamente il valore, non una tupla
                ))
                conn.commit()

            return jsonify({"success": True, "message": "Informazioni aggiornate con successo!"})

        except Exception as e:
            print("Errore:", str(e))
            return jsonify({"success": False, "message": "Errore durante l'aggiornamento: " + str(e)}), 500




@app.route('/admin', methods=['GET', 'POST'])
def admin():
    user_id = session.get('user_id')
    if not user_id:
        return redirect(url_for('login'))

    with get_db() as db:
        user = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        if user['ruolo'] != 'admin':
            return redirect(url_for('home_logged'))

        # Gestione dell'eliminazione dell'annuncio
        if request.method == 'POST' and 'annuncio_id' in request.form:
            annuncio_id = request.form['annuncio_id']
            try:
                # Elimina l'annuncio e le segnalazioni associate
                db.execute('DELETE FROM annuncio WHERE id = ?', (annuncio_id,))
                db.execute('DELETE FROM segnalazioni WHERE annuncio_id = ?', (annuncio_id,))
                db.commit()
                return redirect(url_for('admin'))
            except Exception as e:
                print(f"Errore durante l'eliminazione: {e}")
                db.rollback()
                return "Errore durante l'eliminazione", 500

        # Gestione del cambio ruolo
        elif request.method == 'POST' and 'user_id' in request.form:
            user_id_to_update = request.form['user_id']
            new_role = request.form['new_role']
            try:
                db.execute('UPDATE users SET ruolo = ? WHERE id = ?', (new_role, user_id_to_update))
                db.commit()
            except Exception as e:
                print(f"Errore durante l'aggiornamento del ruolo: {e}")
                db.rollback()
                return "Errore durante l'aggiornamento del ruolo", 500

        # Recupera le segnalazioni esistenti
        segnalazioni = db.execute('''
            SELECT s.*, u.nome as nome_segnalatore, u.cognome as cognome_segnalatore 
            FROM segnalazioni s
            JOIN users u ON s.segnalatore_id = u.id
            ORDER BY s.data_segnalazione DESC
        ''').fetchall()

        # Gestione della ricerca utenti
        search_query = request.args.get('search', '').lower()
        if search_query:
            users = db.execute('''
                SELECT * FROM users 
                WHERE LOWER(nome) LIKE ? 
                OR LOWER(cognome) LIKE ? 
                OR LOWER(email) LIKE ?
            ''', ('%' + search_query + '%',
                 '%' + search_query + '%',
                 '%' + search_query + '%')).fetchall()
        else:
            users = db.execute('SELECT * FROM users').fetchall()

        return render_template('admin.html',
                             users=users,
                             search_query=search_query,
                             segnalazioni=segnalazioni)


@app.route('/studenti_logged')
def studenti_logged():
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    # Recupera gli annunci pubblicati dall'utente
    with get_db() as db:
        # Ottieni tutti gli annunci
        annunci = db.execute("SELECT * FROM annuncio").fetchall()

        # Prepara una lista di annunci con immagini
        annunci_completi = []
        for annuncio in annunci:
            annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario
            immagine = db.execute('''
                        SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
                    ''', (annuncio['id'],)).fetchall()
            annuncio_dict['immagini'] = immagine

            annunci_completi.append(annuncio_dict)
            print(annunci_completi)

    return render_template('studenti_logged.html', iniziali=iniziali,annunci=annunci_completi)

@app.route('/miei-annunci')
def miei_annunci():
    utente_id = session.get('user_id')
    nome = session.get('nome')
    cognome = session.get('cognome')

    if not utente_id:
        return redirect(url_for('login'))

    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    # Recupera gli annunci pubblicati dall'utente
    with get_db() as db:
        annunci = db.execute('''
            SELECT id, titolo, tipologia, descrizione, citta, indirizzo, prezzo, posti, servizi, telefono, email, disponibilita_inizio, disponibilita_fine
            FROM annuncio
            WHERE utente_id = ?
        ''', (utente_id,)).fetchall()



        # Prepara una lista di annunci con immagini
        annunci_completi = []
        for annuncio in annunci:
            annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario
            immagine = db.execute('''
                SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
            ''', (annuncio['id'],)).fetchall()
            annuncio_dict['immagini'] = immagine


            annunci_completi.append(annuncio_dict)
            print(annunci_completi)

    return render_template('Annunci.html', annunci=annunci_completi, iniziali=iniziali)



# Logout route
@app.route('/logout')
def logout():
    # Rimuove specificamente l'utente
    session.pop('user_id', None)
    # Pulisce tutta la sessione
    session.clear()
    # Forza l'eliminazione del cookie di sessione
    session.permanent = False
    return redirect(url_for('home'))


# Route per la pagina dei risultati della ricerca
@app.route('/ricerca', methods=['GET'])
def ricerca():
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''
    destinazione = request.args.get('destinazione', '').lower()
    tipologia = request.args.get('tipologia', '')
    prezzo_max = request.args.get('prezzo', '')
    disponibilita_inizio = request.args.get('check-in', '')
    disponibilita_fine = request.args.get('check-out', '')

    query = "SELECT * FROM annuncio WHERE 1=1"
    params = []

    if destinazione:
        query += " AND LOWER(citta) LIKE ?"
        params.append(f"%{destinazione}%")
    if tipologia:
        query += " AND tipologia = ?"
        params.append(tipologia)
    if prezzo_max:
        query += " AND prezzo <= ?"
        params.append(prezzo_max)
    if disponibilita_inizio:
        query += " AND disponibilita_inizio >= ?"
        params.append(disponibilita_inizio)
    if disponibilita_fine:
        query += " AND disponibilita_fine <= ?"
        params.append(disponibilita_fine)

    conn = sqlite3.connect('unidorm.db')
    conn.row_factory = sqlite3.Row  # Ritorna i risultati come dizionari
    c = conn.cursor()
    c.execute(query, params)
    annunci = c.fetchall()

    # Aggiunge le immagini associate agli annunci
    annunci_completi = []
    for annuncio in annunci:
        annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario

        # Recupera le immagini associate all'annuncio
        immagini = c.execute('''
               SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
           ''', (annuncio['id'],)).fetchall()

        # Aggiungi le immagini al dizionario dell'annuncio
        annuncio_dict['immagini'] = [dict(img) for img in immagini]  # Converti anche le immagini in dizionari

        annunci_completi.append(annuncio_dict)

    conn.close()
    return render_template('risultati_ricerca.html', annunci=annunci_completi,iniziali=iniziali)



@app.route('/modifica-annuncio', methods=['GET', 'POST'])
def modifica_annuncio():
    annuncio_id = request.args.get('annuncio_id')
    utente_id = session.get('user_id')

    if not utente_id:
        return redirect(url_for('login'))

    # Recupera l'annuncio dal database
    with get_db() as db:
        annuncio = db.execute('''
            SELECT id, titolo, tipologia, descrizione, citta, indirizzo, prezzo, posti, servizi, telefono, email, disponibilita_inizio, disponibilita_fine
            FROM annuncio
            WHERE id = ? AND utente_id = ?
        ''', (annuncio_id, utente_id)).fetchone()


        # Recupera le immagini associate all'annuncio
        immagini = db.execute('''
               SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
           ''', (annuncio_id,)).fetchall()

    # Converti l'annuncio in un dizionario per un accesso più semplice


        annuncio_dict = dict(annuncio)
        annuncio_dict['immagini'] = [dict(immagine) for immagine in immagini]

    # Converti le date nel formato richiesto dal template
    disponibilita_inizio = annuncio['disponibilita_inizio']
    disponibilita_fine = annuncio['disponibilita_fine']


    return render_template(
        'Pubblica_annuncio.html',
        annuncio=annuncio_dict,
        disponibilita_inizio=disponibilita_inizio,
        disponibilita_fine=disponibilita_fine
    )

@app.route('/salva-annuncio', methods=['POST'])
def salva_modifica_annuncio():
    utente_id = session.get('user_id')  # Recupera l'ID dell'utente loggato
    annuncio_id = request.form.get('annuncio_id')  # ID dell'annuncio

    if not utente_id:
        return redirect(url_for('login'))  # Se non loggato, reindirizza al login

    # Recupera i dati dal form
    titolo = request.form.get('titolo')
    tipologia = request.form.get('tipologia')
    descrizione = request.form.get('descrizione')
    citta = request.form.get('citta')
    indirizzo = request.form.get('indirizzo')
    prezzo = request.form.get('prezzo')
    posti = request.form.get('posti')
    servizi = ','.join(request.form.getlist('servizi'))
    telefono = request.form.get('telefono')
    email = request.form.get('email')
    disponibilita_inizio = request.form.get('disponibilita_inizio')
    disponibilita_fine = request.form.get('disponibilita_fine')

    # Gestione delle immagini da rimuovere
    rimuovi_immagini_raw = request.form.get('rimuovi_immagini', '[]')  # Ottieni il valore dal form
    if not rimuovi_immagini_raw.strip():  # Controlla se è vuoto o spazi
        rimuovi_immagini_raw = '[]'  # Imposta una lista vuota
    immagini_da_rimuovere = json.loads(rimuovi_immagini_raw)  # Decodifica in lista Python

    # Ora immagini_da_rimuovere è una lista valida, anche se vuota
    if not immagini_da_rimuovere:
        immagini_da_rimuovere = []  # Assicurati che sia una lista vuota

    # Gestione delle nuove immagini caricate
    nuove_immagini = []
    if 'images' in request.files:
        images = request.files.getlist('images')
        if len(images) > 7:  # Limite massimo di immagini
            return "Puoi caricare al massimo 7 immagini", 400

        for image in images:
            if image and allowed_file(image.filename):
                filename = secure_filename(image.filename)
                image_url = os.path.join('images', filename)  # Percorso relativo
                filepath = os.path.join(UPLOAD_FOLDER, filename)  # Percorso assoluto

                # Salva il file sul server
                image.save(filepath)
                nuove_immagini.append(image_url)

    # Aggiorna il database
    with get_db() as db:
        # Rimuovi le immagini selezionate solo se ce ne sono
        if immagini_da_rimuovere:
            for immagine_id in immagini_da_rimuovere:
                db.execute('DELETE FROM immagine_annuncio WHERE id = ? AND annuncio_id = ?', (immagine_id, annuncio_id))
                db.commit()

        # Aggiungi nuove immagini
        for immagine_url in nuove_immagini:
            db.execute('INSERT INTO immagine_annuncio (annuncio_id, url) VALUES (?, ?)', (annuncio_id, immagine_url))
            db.commit()

        # Aggiorna i dati dell'annuncio
        db.execute('''
            UPDATE annuncio
            SET titolo = ?, tipologia = ?, descrizione = ?, citta = ?, indirizzo = ?, prezzo = ?, 
                posti = ?, servizi = ?, telefono = ?, email = ?, disponibilita_inizio = ?, disponibilita_fine = ?
            WHERE id = ? AND utente_id = ?
        ''', (titolo, tipologia, descrizione, citta, indirizzo, prezzo, posti, servizi, telefono, email,
              disponibilita_inizio, disponibilita_fine, annuncio_id, utente_id))
        db.commit()

    return redirect(url_for('miei_annunci'))

@app.route('/elimina-annuncio', methods=['POST'])
def elimina_annuncio():
    # Verifica se l'utente è loggato
    if 'user_id' not in session:
        return redirect(url_for('login'))

    utente_id = session['user_id']  # Ottieni l'ID dell'utente dalla sessione
    annuncio_id = request.form.get('annuncio_id')  # Ottieni l'ID dell'annuncio dal form


    if not annuncio_id:
        return "Errore: ID annuncio non fornito.", 400
        # Cancella l'annuncio solo se appartiene all'utente loggato


    with get_db() as db:
        result = db.execute('DELETE FROM annuncio WHERE id = ? AND utente_id = ?', (annuncio_id, utente_id))

        db.execute('''
                        DELETE FROM immagine_annuncio WHERE annuncio_id = ?
                   ''', (annuncio_id,)).fetchall()
        if result.rowcount == 0:
            return "Errore: Annuncio non trovato o non autorizzato.", 403

    # Reindirizza alla pagina dei miei annunci
    return redirect(url_for('miei_annunci'))

@app.route('/ricerca_host', methods=['GET'])
def ricerca_host():

    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''
    destinazione = request.args.get('destinazione', '').lower()
    tipologia = request.args.get('tipologia', '')
    prezzo_max = request.args.get('prezzo', '')
    disponibilita_inizio = request.args.get('check-in', '')
    disponibilita_fine = request.args.get('check-out', '')

    query = "SELECT * FROM annuncio WHERE 1=1"
    params = []

    if destinazione:
        query += " AND LOWER(citta) LIKE ?"
        params.append(f"%{destinazione}%")
    if tipologia:
        query += " AND tipologia = ?"
        params.append(tipologia)
    if prezzo_max:
        query += " AND prezzo <= ?"
        params.append(prezzo_max)
    if disponibilita_inizio:
        query += " AND disponibilita_inizio >= ?"
        params.append(disponibilita_inizio)
    if disponibilita_fine:
        query += " AND disponibilita_fine <= ?"
        params.append(disponibilita_fine)

    conn = sqlite3.connect('unidorm.db')
    conn.row_factory = sqlite3.Row  # Ritorna i risultati come dizionari
    c = conn.cursor()
    c.execute(query, params)
    annunci = c.fetchall()

    # Aggiunge le immagini associate agli annunci
    annunci_completi = []
    for annuncio in annunci:
        annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario

        # Recupera le immagini associate all'annuncio
        immagini = c.execute('''
               SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
           ''', (annuncio['id'],)).fetchall()

        # Aggiungi le immagini al dizionario dell'annuncio
        annuncio_dict['immagini'] = [dict(img) for img in immagini]  # Converti anche le immagini in dizionari

        annunci_completi.append(annuncio_dict)

    conn.close()

    return render_template('risultati_ricercaHost.html', annunci=annunci_completi,iniziali=iniziali)


@app.route('/ricerca_s', methods=['GET'])
def ricerca_stud():

    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''
    destinazione = request.args.get('destinazione', '').lower()
    tipologia = request.args.get('tipologia', '')
    prezzo_max = request.args.get('prezzo', '')
    disponibilita_inizio = request.args.get('check-in', '')
    disponibilita_fine = request.args.get('check-out', '')

    query = "SELECT * FROM annuncio WHERE 1=1"
    params = []

    if destinazione:
        query += " AND LOWER(citta) LIKE ?"
        params.append(f"%{destinazione}%")
    if tipologia:
        query += " AND tipologia = ?"
        params.append(tipologia)
    if prezzo_max:
        query += " AND prezzo <= ?"
        params.append(prezzo_max)
    if disponibilita_inizio:
        query += " AND disponibilita_inizio >= ?"
        params.append(disponibilita_inizio)
    if disponibilita_fine:
        query += " AND disponibilita_fine <= ?"
        params.append(disponibilita_fine)

    conn = sqlite3.connect('unidorm.db')
    conn.row_factory = sqlite3.Row  # Ritorna i risultati come dizionari
    c = conn.cursor()
    c.execute(query, params)
    annunci = c.fetchall()

    # Aggiunge le immagini associate agli annunci
    annunci_completi = []
    for annuncio in annunci:
        annuncio_dict = dict(annuncio)  # Converti la riga in un dizionario

        # Recupera le immagini associate all'annuncio
        immagini = c.execute('''
               SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
           ''', (annuncio['id'],)).fetchall()

        # Aggiungi le immagini al dizionario dell'annuncio
        annuncio_dict['immagini'] = [dict(img) for img in immagini]  # Converti anche le immagini in dizionari

        annunci_completi.append(annuncio_dict)

    conn.close()
    return render_template('risultati_ricerca_s.html', annunci=annunci_completi,iniziali=iniziali)


@app.route('/prenota/<int:annuncio_id>', methods=['GET', 'POST'])
def prenota_annuncio(annuncio_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    # Recupera i dati dell'annuncio
    with get_db() as db:
        annuncio = db.execute('SELECT * FROM annuncio WHERE id = ?', (annuncio_id,)).fetchone()

    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    # Parsing delle date limite dal database
    data_min = datetime.strptime(annuncio[12], '%Y-%m-%d')  # Ora senza orario
    data_max = datetime.strptime(annuncio[13], '%Y-%m-%d')  # Ora senza orario

    if request.method == 'POST':
        data_inizio = request.form['data_inizio']
        data_fine = request.form['data_fine']
        note = request.form.get('note', '')
        numero_ospiti = 1  # Ogni prenotazione aggiunge automaticamente 1 ospite

        # Parsing delle date
        data_inizio_dt = datetime.strptime(data_inizio, '%Y-%m-%d')
        data_fine_dt = datetime.strptime(data_fine, '%Y-%m-%d')

        # Controllo se le date sono nel range
        if data_inizio_dt < data_min or data_fine_dt > data_max:
            errore = "Le date selezionate non sono disponibili per questo annuncio. Verifica il range disponibile."
            return render_template('prenota_annuncio.html', annuncio=annuncio, iniziali=iniziali, errore=errore)

        # Controllo sovrapposizioni di prenotazione
        with get_db() as db:
            query = '''
            SELECT data_inizio, data_fine, SUM(numero_ospiti) as totale_ospiti
            FROM prenotazioni
            WHERE annuncio_id = ?
            AND (
                (data_inizio <= ? AND data_fine >= ?) OR
                (data_inizio >= ? AND data_fine <= ?)
            )
            GROUP BY data_inizio, data_fine
            '''
            prenotazioni_conflitto = db.execute(query, (annuncio_id, data_fine, data_inizio, data_inizio, data_fine)).fetchall()

            # Calcolo totale ospiti nelle date richieste
            totale_ospiti = sum([row['totale_ospiti'] for row in prenotazioni_conflitto])

            # Controllo disponibilità posti
            posti_disponibili = annuncio[8]  # Numero massimo di posti nell'annuncio
            if totale_ospiti + numero_ospiti > posti_disponibili:
                errore = f"Non ci sono abbastanza posti disponibili per le date selezionate. Posti rimanenti: {posti_disponibili - totale_ospiti}."
                return render_template('prenota_annuncio.html', annuncio=annuncio, iniziali=iniziali, errore=errore)

            # Salva la prenotazione
            utente_id = session['user_id']
            db.execute('''
                           INSERT INTO prenotazioni (utente_id, annuncio_id, data_inizio, data_fine, numero_ospiti, note)
                           VALUES (?, ?, ?, ?, ?, ?)
                       ''', (utente_id, annuncio_id, data_inizio, data_fine, numero_ospiti, note))
            db.commit()

            return render_template('conferma_prenotazione.html', annuncio=annuncio, iniziali=iniziali)

    return render_template('prenota_annuncio.html', annuncio=annuncio, iniziali=iniziali,disponibilita_inizio=data_min.strftime('%Y-%m-%d'),
                         disponibilita_fine=data_max.strftime('%Y-%m-%d'))

@app.route('/elimina-prenotazione/<int:prenotazione_id>', methods=['POST'])
def elimina_prenotazione(prenotazione_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    with get_db() as db:
        db.execute('DELETE FROM prenotazioni WHERE id = ?', (prenotazione_id,))
        db.commit()

    return redirect(url_for('visualizza_prenotazioni'))



@app.route('/modifica-prenotazione/<int:prenotazione_id>', methods=['GET', 'POST'])
def modifica_prenotazione(prenotazione_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    with get_db() as db:
        prenotazione = db.execute('SELECT * FROM prenotazioni WHERE id = ? AND utente_id = ?',
                                  (prenotazione_id, session['user_id'])).fetchone()

    if not prenotazione:
        return redirect(url_for('visualizza_prenotazioni'))

    annuncio_id = prenotazione['annuncio_id']

    with get_db() as db:
        annuncio = db.execute('SELECT * FROM annuncio WHERE id = ?', (annuncio_id,)).fetchone()

    disponibilita_inizio = datetime.strptime(annuncio['disponibilita_inizio'], '%Y-%m-%d').date()
    disponibilita_fine = datetime.strptime(annuncio['disponibilita_fine'], '%Y-%m-%d').date()

    if request.method == 'POST':
        nuova_data_inizio = request.form['data_inizio']
        nuova_data_fine = request.form['data_fine']
        nuove_note = request.form.get('note', '')

        nuova_data_inizio_dt = datetime.strptime(nuova_data_inizio, '%Y-%m-%d').date()
        nuova_data_fine_dt = datetime.strptime(nuova_data_fine, '%Y-%m-%d').date()

        if nuova_data_inizio_dt < disponibilita_inizio or nuova_data_fine_dt > disponibilita_fine:
            errore = "Le date devono essere comprese nell'intervallo di disponibilità dell'annuncio."
            return render_template('modifica_prenotazione.html', prenotazione=prenotazione, errore=errore)

        with get_db() as db:
            query = '''
            SELECT SUM(numero_ospiti) as totale_ospiti
            FROM prenotazioni
            WHERE annuncio_id = ? 
            AND (
                (data_inizio <= ? AND data_fine >= ?) OR
                (data_inizio >= ? AND data_fine <= ?)
            )
            '''
            prenotazioni_conflitto = db.execute(query, (annuncio_id, nuova_data_fine, nuova_data_inizio, nuova_data_inizio, nuova_data_fine)).fetchone()

            totale_ospiti = prenotazioni_conflitto['totale_ospiti'] or 0
            posti_disponibili = annuncio['posti']

            if totale_ospiti + prenotazione['numero_ospiti'] > posti_disponibili:
                errore = f"Non ci sono abbastanza posti disponibili per le nuove date selezionate. Posti rimanenti: {posti_disponibili - totale_ospiti}."
                return render_template('modifica_prenotazione.html', prenotazione=prenotazione, errore=errore)

            db.execute('''UPDATE prenotazioni
                          SET data_inizio = ?, data_fine = ?, note = ?
                          WHERE id = ?''', (nuova_data_inizio, nuova_data_fine, nuove_note, prenotazione_id))
            db.commit()

            return redirect(url_for('visualizza_prenotazioni'))

    return render_template('modifica_prenotazione.html', prenotazione=prenotazione,disponibilita_inizio=disponibilita_inizio,disponibilita_fine=disponibilita_fine,iniziali=iniziali)

@app.route('/le-mie-prenotazioni')
def visualizza_prenotazioni():
    # Verifica che l'utente sia loggato
    if 'user_id' not in session:
        return redirect(url_for('login'))

    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    utente_id = session['user_id']

    # Recupera tutte le prenotazioni dell'utente
    with get_db() as db:
        prenotazioni = db.execute('''
            SELECT p.id, a.titolo, p.data_inizio, p.data_fine, p.numero_ospiti, p.note
            FROM prenotazioni p
            JOIN annuncio a ON p.annuncio_id = a.id
            WHERE p.utente_id = ?
        ''', (utente_id,)).fetchall()

    return render_template('visualizza_prenotazioni.html', prenotazioni=prenotazioni,iniziali=iniziali)

















@app.route('/account', methods=['GET'])
def get_account():
    # Recupera l'ID dell'utente loggato
    utente_id = session.get('user_id')
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    if not utente_id:
        return redirect(url_for('login'))  # Se non loggato, reindirizza al login

    # Recupera le informazioni dell'utente dal database
    with get_db() as db:
        utente = db.execute('''
            SELECT nome, cognome, email, data_nascita,password,ruolo,universita,matricola,corso_laurea
            FROM users
            WHERE id = ?
        ''', (utente_id,)).fetchone()

    if not utente:
        return "Errore: Utente non trovato.", 404

    # Passa le informazioni dell'utente al template
    return render_template('account.html',
                           utente_id=utente_id,
                           nome=utente['nome'],
                           cognome=utente['cognome'],
                           email=utente['email'],
                           data_nascita=utente['data_nascita'],
                           password=utente['password'],
                           ruolo=utente['ruolo'],
                           universita=utente['universita'],
                           matricola=utente['matricola'],
                           corso_laurea=utente['corso_laurea'],
                           iniziali=iniziali)


@app.route('/modifica-account', methods=['POST'])
def modifica_account():
    # Recupera l'ID dell'utente loggato
    utente_id = session.get('user_id')

    if not utente_id:
        return redirect(url_for('login'))  # Se non loggato, reindirizza al login

    # Recupera i dati dal form
    nome = request.form.get('nome')
    cognome = request.form.get('cognome')
    email = request.form.get('email')
    data_nascita = request.form.get('data_nascita') or None  # Può essere facoltativa

    # Aggiorna le informazioni dell'utente nel database
    with get_db() as db:
        db.execute('''
            UPDATE users
            SET nome = ?, cognome = ?, email = ?, data_nascita = ?
            WHERE id = ?
        ''', (nome, cognome, email, data_nascita, utente_id))
        db.commit()

    return redirect(url_for('get_account'))


@app.route('/elimina-account', methods=['POST'])
def elimina_account():
    # Recupera l'ID dell'utente loggato
    utente_id = session.get('user_id')

    # Connessione al database
    with get_db() as db:
        # Recupera gli ID degli annunci dell'utente
        annunci = db.execute('SELECT id FROM annuncio WHERE utente_id = ?', (utente_id,)).fetchall()

        for annuncio in annunci:
            annuncio_id = annuncio['id']

            # Recupera i percorsi delle immagini associate all'annuncio
            immagini = db.execute('SELECT url FROM immagine_annuncio WHERE annuncio_id = ?', (annuncio_id,)).fetchall()

            # Elimina fisicamente le immagini dal file system
            for immagine in immagini:
                try:
                    os.remove(os.path.join('static', immagine['url']))
                except FileNotFoundError:
                    print(f"Immagine {immagine['url']} non trovata, continuando...")

            # Elimina le immagini dalla tabella `immagine_annuncio`
            db.execute('DELETE FROM immagine_annuncio WHERE annuncio_id = ?', (annuncio_id,))

        # Elimina gli annunci associati all'utente
        db.execute('DELETE FROM annuncio WHERE utente_id = ?', (utente_id,))

        # Elimina l'utente dalla tabella `users`
        db.execute('DELETE FROM users WHERE id = ?', (utente_id,))
        db.commit()

    # Rimuove l'utente dalla sessione
    session.clear()

    return redirect(url_for('home'))  # Torna alla homepage




@app.route('/dettagli-annuncio_h/<int:annuncio_id>',methods=['GET', 'POST'])
def dettagli_annuncio_h(annuncio_id):
    # Gestione delle segnalazioni (POST)
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        try:
            id_annuncio = request.form.get('id_annuncio')
            id_segnalatore = request.form.get('id_segnalatore')
            motivazione = request.form.get('motivazione')

            if not all([id_annuncio, id_segnalatore, motivazione]):
                return jsonify({'success': False, 'message': 'Dati mancanti'})

            with get_db() as db:
                # Inserisci la segnalazione
                db.execute('''
                    INSERT INTO segnalazioni (annuncio_id, segnalatore_id, motivazione, data_segnalazione)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                ''', (id_annuncio, id_segnalatore, motivazione))

                # Recupera il titolo dell'annuncio per il messaggio di notifica
                annuncio_titolo = db.execute('''
                    SELECT titolo FROM annuncio WHERE id = ?
                ''', (id_annuncio,)).fetchone()['titolo']

                # Recupera tutti gli utenti admin
                admin_users = db.execute('''
                    SELECT id FROM users WHERE ruolo = 'admin'
                ''').fetchall()

                # Crea una notifica per ogni admin
                for admin in admin_users:
                    contenuto = f"Nuova segnalazione per l'annuncio '{annuncio_titolo}'. Motivazione: {motivazione}"
                    db.execute('''
                        INSERT INTO notifiche (user_id, tipo, contenuto, data_creazione)
                        VALUES (?, 'segnalazione', ?, CURRENT_TIMESTAMP)
                    ''', (admin['id'], contenuto))

                db.commit()

            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'success': False, 'message': str(e)})

    #Resto invariato
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    with get_db() as db:
        # Recupera i dettagli dell'annuncio
        annuncio = db.execute('''
            SELECT a.id, a.titolo, a.tipologia, a.descrizione, a.citta, a.indirizzo, a.prezzo, a.posti, a.servizi,
                   a.telefono, a.email, a.disponibilita_inizio, a.disponibilita_fine, u.nome AS autore_nome, u.cognome AS autore_cognome
            FROM annuncio a
            JOIN users u ON a.utente_id = u.id
            WHERE a.id = ?
        ''', (annuncio_id,)).fetchone()


        # Recupera le immagini associate all'annuncio
        immagini = db.execute('''
                      SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
                  ''', (annuncio_id,)).fetchall()

        # Converti l'annuncio in un dizionario per un accesso più semplice
        annuncio_dict = dict(annuncio)
        annuncio_dict['immagini'] = [dict(immagine) for immagine in immagini]

    return render_template('Annuncio_singolo_h.html', annuncio=annuncio_dict,
                           iniziali=iniziali, autore_nome=annuncio['autore_nome'],
                           autore_cognome=annuncio['autore_cognome'])


@app.route('/dettagli-annuncio_s/<int:annuncio_id>',methods=['GET', 'POST'])
def dettagli_annuncio_s(annuncio_id):

    # Gestione delle segnalazioni (POST)
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        try:
            id_annuncio = request.form.get('id_annuncio')
            id_segnalatore = request.form.get('id_segnalatore')
            motivazione = request.form.get('motivazione')

            if not all([id_annuncio, id_segnalatore, motivazione]):
                return jsonify({'success': False, 'message': 'Dati mancanti'})

            with get_db() as db:
                # Inserisci la segnalazione
                db.execute('''
                        INSERT INTO segnalazioni (annuncio_id, segnalatore_id, motivazione, data_segnalazione)
                        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ''', (id_annuncio, id_segnalatore, motivazione))

                # Recupera il titolo dell'annuncio per il messaggio di notifica
                annuncio_titolo = db.execute('''
                        SELECT titolo FROM annuncio WHERE id = ?
                    ''', (id_annuncio,)).fetchone()['titolo']

                # Recupera tutti gli utenti admin
                admin_users = db.execute('''
                        SELECT id FROM users WHERE ruolo = 'admin'
                    ''').fetchall()

                # Crea una notifica per ogni admin
                for admin in admin_users:
                    contenuto = f"Nuova segnalazione per l'annuncio '{annuncio_titolo}'. Motivazione: {motivazione}"
                    db.execute('''
                            INSERT INTO notifiche (user_id, tipo, contenuto, data_creazione)
                            VALUES (?, 'segnalazione', ?, CURRENT_TIMESTAMP)
                        ''', (admin['id'], contenuto))

                db.commit()

            return jsonify({'success': True})
        except Exception as e:
            return jsonify({'success': False, 'message': str(e)})

    #parte restante
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''

    with get_db() as db:
        # Recupera i dettagli dell'annuncio
        annuncio = db.execute('''
            SELECT a.id, a.titolo, a.tipologia, a.descrizione, a.citta, a.indirizzo, a.prezzo, a.posti, a.servizi,
                   a.telefono, a.email, a.disponibilita_inizio, a.disponibilita_fine, u.nome AS autore_nome, u.cognome AS autore_cognome
            FROM annuncio a
            JOIN users u ON a.utente_id = u.id
            WHERE a.id = ?
        ''', (annuncio_id,)).fetchone()


        # Recupera le immagini associate all'annuncio
        immagini = db.execute('''
                      SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
                  ''', (annuncio_id,)).fetchall()

        # Converti l'annuncio in un dizionario per un accesso più semplice
        annuncio_dict = dict(annuncio)
        annuncio_dict['immagini'] = [dict(immagine) for immagine in immagini]

    return render_template('Annuncio singolo_s.html', annuncio=annuncio_dict,
                           iniziali=iniziali, autore_nome=annuncio['autore_nome'],
                           autore_cognome=annuncio['autore_cognome'])


@app.route('/dettagli-annuncio/<int:annuncio_id>')
def dettagli_annuncio(annuncio_id):

    with get_db() as db:
        # Recupera i dettagli dell'annuncio
        annuncio = db.execute('''
            SELECT a.id, a.titolo, a.tipologia, a.descrizione, a.citta, a.indirizzo, a.prezzo, a.posti, a.servizi,
                   a.telefono, a.email, a.disponibilita_inizio, a.disponibilita_fine, u.nome AS autore_nome, u.cognome AS autore_cognome
            FROM annuncio a
            JOIN users u ON a.utente_id = u.id
            WHERE a.id = ?
        ''', (annuncio_id,)).fetchone()


        # Recupera le immagini associate all'annuncio
        immagini = db.execute('''
                      SELECT id, url FROM immagine_annuncio WHERE annuncio_id = ?
                  ''', (annuncio_id,)).fetchall()

        # Converti l'annuncio in un dizionario per un accesso più semplice
        annuncio_dict = dict(annuncio)
        annuncio_dict['immagini'] = [dict(immagine) for immagine in immagini]

    return render_template('Annuncio singolo.html', annuncio=annuncio_dict,
                           autore_nome=annuncio['autore_nome'],
                           autore_cognome=annuncio['autore_cognome'])


@app.route('/supporto')
def supporto():
    nome = session.get('nome')
    cognome = session.get('cognome')
    iniziali = nome[0].upper() + cognome[0].upper() if nome and cognome else ''
    print(nome, cognome)
    return render_template('supporto.html',iniziali=iniziali)



# Avvio del server
if __name__ == '__main__':
    init_db()
    app.run(debug=True)