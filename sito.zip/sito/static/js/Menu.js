// Funzione per aprire/chiudere il menu del profilo
function toggleMenu() {
    var menu = document.querySelector(".dropdown-menu");
    menu.style.display = (menu.style.display === "block") ? "none" : "block";
}