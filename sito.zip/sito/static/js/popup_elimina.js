//Codice js per gestire il comportamento del popup di conferma eliminazione di un annuncio

document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('confirmation-modal');
    const confirmButton = document.getElementById('confirm-delete');
    const cancelButton = document.getElementById('cancel-delete');
    let formToSubmit = null;

    // Intercetta i submit dei form con classe "delete-form"
    document.querySelectorAll('.delete-form').forEach(form => {
        form.addEventListener('submit', (e) => {
            e.preventDefault(); // Impedisce il submit immediato
            formToSubmit = form; // Memorizza il form corrente
            modal.style.display = 'flex'; // Mostra il popup
        });
    });

    // Gestisce il clic sul pulsante "Conferma"
    confirmButton.addEventListener('click', () => {
        if (formToSubmit) formToSubmit.submit(); // Invia il form
        modal.style.display = 'none'; // Nasconde il popup
    });

    // Gestisce il clic sul pulsante "Annulla"
    cancelButton.addEventListener('click', () => {
        modal.style.display = 'none'; // Nasconde il popup
    });
});