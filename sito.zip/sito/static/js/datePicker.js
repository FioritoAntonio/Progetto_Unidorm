// Configurazione comune per flatpickr
const dateConfig = {
    locale: "it",
    dateFormat: "Y-m-d",
    altInput: true,
    altFormat: "d/m/Y",
    disableMobile: "true",
    minDate: Math.max(new Date(), new Date(disponibilita_inizio)), // Prende la data più recente tra oggi e disponibilita_inizio
    maxDate: disponibilita_fine,
    enable: [
        {
            from: disponibilita_inizio,
            to: disponibilita_fine
        }
    ]
};

// Funzione per ottenere il giorno successivo
const getTomorrow = (date) => {
    const tomorrow = new Date(date);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow;
};

// Inizializzazione del datepicker per la data di inizio
const dataInizioPicker = flatpickr("#data_inizio", {
    ...dateConfig,
    onChange: function(selectedDates, dateStr) {
        // Aggiorna la data minima del datepicker di fine al giorno successivo
        if (selectedDates[0]) {
            const nextDay = getTomorrow(selectedDates[0]);
            dataFinePicker.set('minDate', nextDay);
            // Se la data di fine è minore o uguale alla nuova data di inizio, resetta la data di fine
            if (dataFinePicker.selectedDates[0] && dataFinePicker.selectedDates[0] <= selectedDates[0]) {
                dataFinePicker.clear();
            }
        }
    }
});

// Inizializzazione del datepicker per la data di fine
const dataFinePicker = flatpickr("#data_fine", {
    ...dateConfig,
    minDate: document.getElementById('data_inizio').value
        ? getTomorrow(new Date(document.getElementById('data_inizio').value))
        : getTomorrow(Math.max(new Date(), new Date(disponibilita_inizio))),
    onChange: function(selectedDates) {
        // Validazione aggiuntiva per assicurarsi che la data fine sia dopo la data inizio
        const dataInizio = dataInizioPicker.selectedDates[0];
        if (dataInizio && selectedDates[0] <= dataInizio) {
            this.clear();
        }
    }
});

// Imposta i valori iniziali se presenti
document.addEventListener('DOMContentLoaded', function() {
    const dataInizio = document.getElementById('data_inizio').value;
    const dataFine = document.getElementById('data_fine').value;

    if (dataInizio) {
        dataInizioPicker.setDate(dataInizio);
    }
    if (dataFine) {
        dataFinePicker.setDate(dataFine);
    }
});