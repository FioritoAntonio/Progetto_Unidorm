/* Funzione per gestire la visualizzazione dell'anteprima*/

function previewImages() {
    const files = document.getElementById('immagini').files;
    const previewContainer = document.getElementById('imagePreview');

    // Svuota l'anteprima esistente
    previewContainer.innerHTML = '';

    // Cicla attraverso tutti i file selezionati
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const reader = new FileReader();

        reader.onload = function(event) {
            const imagePreview = document.createElement('div');
            imagePreview.classList.add('image-preview');
            imagePreview.id = 'image-preview-' + i; // Aggiungi un ID univoco per ciascuna anteprima

            const imgElement = document.createElement('img');
            imgElement.src = event.target.result;

            const removeBtn = document.createElement('button');
            removeBtn.classList.add('remove-btn');
            removeBtn.textContent = 'X';

            removeBtn.onclick = function() {
                // Rimuove l'anteprima quando cliccato
                imagePreview.remove();
                // Rende di nuovo il file selezionabile
                const inputElement = document.getElementById('immagini');
                inputElement.value = ''; // Reset il campo di input
            };

            imagePreview.appendChild(imgElement);
            imagePreview.appendChild(removeBtn);
            previewContainer.appendChild(imagePreview);
        };

        reader.readAsDataURL(file);
    }
}


document.addEventListener('DOMContentLoaded', () => {
    let immaginiDaRimuovere = []; // Array per tracciare le immagini da rimuovere

    // Seleziona tutti i pulsanti con la classe "remove-btn"
    const removeButtons = document.querySelectorAll('.remove-btn');

    removeButtons.forEach(button => {
        button.addEventListener('click', () => {
            const imageId = button.getAttribute('data-id'); // Recupera l'ID dell'immagine dal dataset

            // Nascondi l'anteprima dell'immagine
            const imageElement = document.getElementById('image-${imageId}');
            if (imageElement) {
                imageElement.style.display = 'none';
            }

            // Aggiungi l'ID dell'immagine all'array
            if (!immaginiDaRimuovere.includes(imageId)) {
                immaginiDaRimuovere.push(imageId);
            }

            // Aggiorna il valore dell'input nascosto
            const inputElement = document.getElementById('rimuovi-immagini');
            inputElement.value = JSON.stringify(immaginiDaRimuovere);
        });
    });
});