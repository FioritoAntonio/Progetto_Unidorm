document.addEventListener('DOMContentLoaded', () => {
    // Seleziona tutti i caroselli sulla pagina
    const carousels = document.querySelectorAll('.carousel');

    carousels.forEach(carousel => {
        // Aggiungi l'evento di click ai controlli prev e next
        const prevButton = carousel.querySelector('.carousel-control-prev');
        const nextButton = carousel.querySelector('.carousel-control-next');

        if (prevButton) {
            prevButton.addEventListener('click', event => {
                event.stopPropagation(); // Impedisce la propagazione al container della card
            });
        }

        if (nextButton) {
            nextButton.addEventListener('click', event => {
                event.stopPropagation(); // Impedisce la propagazione al container della card
            });
        }
    });
});
