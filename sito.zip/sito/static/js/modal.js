// Debug iniziale
console.log('Script di eliminazione inizializzato');

let idAnnuncioCorrente = null;

// Funzione per mostrare il modal
function mostraModalEliminazione(idAnnuncio) {
    console.log('mostraModalEliminazione chiamata con ID:', idAnnuncio);
    if (!idAnnuncio) {
        console.error('ID annuncio mancante!');
        return;
    }
    idAnnuncioCorrente = idAnnuncio;

    const modalElement = document.getElementById('modalEliminazione');
    const modalPersonalizzato = document.querySelector('.modal-personalizzato');

    if (!modalElement) {
        console.error('Elemento modal non trovato!');
        return;
    }
    if (!modalPersonalizzato) {
        console.error('Elemento .modal-personalizzato non trovato!');
        return;
    }

    modalElement.style.display = 'block';
    modalPersonalizzato.style.display = 'block';
    console.log('Modal visualizzato con successo');
}

// Funzione per chiudere il modal
function chiudiModalEliminazione() {
    console.log('Chiusura modal');
    document.getElementById('modalEliminazione').style.display = 'none';
    document.querySelector('.modal-personalizzato').style.display = 'none';
    idAnnuncioCorrente = null;
}

// Funzione per confermare l'eliminazione
function confermaEliminazione() {
    console.log('confermaEliminazione chiamata, ID corrente:', idAnnuncioCorrente);
    if (idAnnuncioCorrente) {
        console.log('Invio richiesta di eliminazione per ID:', idAnnuncioCorrente);

        // Uso di fetch con la route esistente
        fetch('/admin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'annuncio_id=' + encodeURIComponent(idAnnuncioCorrente)
        })
        .then(response => {
            console.log('Risposta ricevuta:', response.status);
            if (response.ok) {
                console.log('Annuncio eliminato con successo');
                // Rimuovo l'alert come richiesto
                location.reload(); // Ricarica la pagina
            } else {
                console.error('Errore durante l\'eliminazione', response);
                alert('Si è verificato un errore durante l\'eliminazione dell\'annuncio.');
            }
        })
        .catch(error => {
            console.error('Errore di rete:', error);
            alert('Si è verificato un errore di connessione.');
        });
    } else {
        console.error('Nessun ID annuncio corrente da eliminare!');
    }
    chiudiModalEliminazione();
}

// Chiudi il modal quando si clicca fuori
document.getElementById('modalEliminazione')?.addEventListener('click', function(e) {
    if (e.target === this) {
        chiudiModalEliminazione();
    }
});

// Chiudi il modal con il tasto ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        chiudiModalEliminazione();
    }
});

// Debug per i pulsanti dopo il caricamento del DOM
window.addEventListener('DOMContentLoaded', () => {
    console.log('DOM caricato - script pronto');
    console.log('Cercando pulsanti di eliminazione...');
    const buttonsElimina = document.querySelectorAll('.btn-danger.btn-sm');
    console.log('Trovati ' + buttonsElimina.length + ' pulsanti di eliminazione');

    // Verifica che i pulsanti abbiano l'onclick corretto
    buttonsElimina.forEach((button, index) => {
        const onclickAttr = button.getAttribute('onclick');
        console.log(`  onclick: ${onclickAttr}`);

        // Aggiungi listener di backup
        button.addEventListener('click', function(e) {
            console.log('Pulsante eliminazione cliccato via addEventListener!', this);
            // Prova a estrarre l'ID dall'attributo onclick se esiste
            if (onclickAttr) {
                const match = onclickAttr.match(/mostraModalEliminazione\(['"]([^'"]+)['"]\)/);
                if (match && match[1]) {
                    console.log('ID estratto dall\'onclick:', match[1]);
                    mostraModalEliminazione(match[1]);
                }
            }
        });
    });

    // Verifica che il modal esista
    const modal = document.getElementById('modalEliminazione');
    console.log('Modal trovato:',!!modal);
});