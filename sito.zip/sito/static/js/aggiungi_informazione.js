document.getElementById("aggiungi_informazioni").addEventListener("submit", async function(event) {
    event.preventDefault(); // Previene il comportamento di submit predefinito

    const messageBox = document.getElementById('messageBox');
    const username = document.getElementById('username').value; // Campo username
    const password = document.getElementById('password').value; // Campo password

    messageBox.textContent = ''; // Resetta il messaggio

    try {
        // Simula la chiamata all'API dell'università per il login
        const credentials = btoa(`${username}:${password}`);
        const response = await fetch('https://api.uniparthenope.it/UniparthenopeApp/v1/login', {
            method: 'GET',
            headers: {
                'Authorization': `Basic ${credentials}`
            }
        });

        if (!response.ok) {
            throw new Error('Credenziali non valide');
        }

        const data = await response.json();

        // Log dei dati restituiti dall'API per il debug
        console.log("Dati ricevuti dall'API:", data);

        // Prepara i dati da inviare al backend
        const studentData = {
            matricola: data.user.trattiCarriera[0].matricola, // Matricola
            corso_laurea: data.user.trattiCarriera[0].cdsDes, // Corso di laurea
            universita: "Università Parthenope", // Università
        };

        // Log dei dati che verranno inviati al backend
        console.log("Dati inviati al backend:", studentData);

        // Invia i dati al backend per l'aggiunta delle informazioni
        const saveResponse = await fetch('/aggiungi-informazioni', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(studentData)
        });

        const result = await saveResponse.json();

        if (result.success) {
            messageBox.textContent = "Informazioni aggiunte con successo!";
            messageBox.style.color = "green";
            window.location.href = '/studenti_logged'; // Redirige alla pagina di login
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        messageBox.textContent = `Errore: ${error.message}`;
        messageBox.style.color = "red";
    }
});
