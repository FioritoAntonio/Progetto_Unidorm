document.getElementById("studentRegistrationForm").addEventListener("submit", async function(event) {
    event.preventDefault(); // Previene il comportamento di submit predefinito

    const messageBox = document.getElementById('messageBox');
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const email = document.getElementById('email').value;
    const dataNascita = document.getElementById('data_nascita').value; // Aggiunto campo data di nascita

    messageBox.textContent = ''; // Resetta il messaggio

    try {
        // Simula la chiamata all'API dell'università
        const credentials = btoa(`${username}:${password}`);
        const response = await fetch('https://api.uniparthenope.it/UniparthenopeApp/v1/login', {
            method: 'GET',
            headers: {
                'Authorization': `Basic ${credentials}`
            }
        });

        if (!response.ok) {
            throw new Error('Credenziali non valide');
        }

        const data = await response.json();

        // Log dei dati restituiti dall'API per il debug
        console.log("Dati ricevuti dall'API:", data);

        // Prepara i dati da inviare al backend con la chiave `data_nascita`
        const studentData = {
            nome: data.user.firstName,
            cognome: data.user.lastName,
            matricola: data.user.trattiCarriera[0].matricola,
            universita: "Università Parthenope", // Può essere dinamico se necessario
            corso_laurea: data.user.trattiCarriera[0].cdsDes,
            password: password,
            email: email,
            data_nascita: dataNascita // Aggiunto campo data di nascita
        };

        // Log dei dati che verranno inviati al backend
        console.log("Dati inviati al backend:", studentData);

        // Invia i dati al backend
        const saveResponse = await fetch('/registrazione-studente', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(studentData)
        });

        const result = await saveResponse.json();

        if (result.success) {
            messageBox.textContent = "Registrazione completata con successo!";
            messageBox.style.color = "green";
            window.location.href = '/login';
        } else {
            throw new Error(result.message);
        }
    } catch (error) {
        messageBox.textContent = `Errore: ${error.message}`;
        messageBox.style.color = "red";
    }
});
