// Funzione per aprire il modal di segnalazione
function apriModalSegnalazione(idAnnuncio, idSegnalatore) {
    console.log('Apertura modal con:', { idAnnuncio, idSegnalatore });
    document.getElementById('idAnnuncio').value = idAnnuncio;
    document.getElementById('idSegnalatore').value = idSegnalatore;
    const modal = new bootstrap.Modal(document.getElementById('segnalazioneModal'));
    modal.show();
}

// Funzione per validare i campi
function validaCampi() {
    const motivazione = document.getElementById('motivazione').value.trim();
    console.log('Validazione campi - Motivazione:', motivazione);
    if (!motivazione) {
        mostraErrore('Per favore inserisci una motivazione');
        return false;
    }
    return true;
}

// Funzione per mostrare errori
function mostraErrore(messaggio) {
    console.error('Errore:', messaggio);
    const modalBody = document.querySelector('.modal-body');
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-danger alert-dismissible fade show mt-3';
    alertDiv.innerHTML = `
        ${messaggio}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    modalBody.appendChild(alertDiv);
}

// Funzione per mostrare successo
function mostraSuccesso(messaggio) {
    console.log('Successo:', messaggio);
    const modalBody = document.querySelector('.modal-body');
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show mt-3';
    alertDiv.innerHTML = `
        ${messaggio}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    modalBody.appendChild(alertDiv);
}

// Inizializzazione degli event listener
document.addEventListener('DOMContentLoaded', function() {
    console.log('Inizializzazione event listeners');
    const segnalazioneModal = document.getElementById('segnalazioneModal');
    const segnalazioneForm = document.getElementById('segnalazioneForm');

    // Prevenire l'invio del form con il tasto Invio
    segnalazioneForm?.addEventListener('submit', function(e) {
        console.log('Form submit intercettato');
        e.preventDefault();
        inviaSegnalazione();
    });

    // Pulizia del form quando il modal viene chiuso
    segnalazioneModal?.addEventListener('hidden.bs.modal', function () {
        console.log('Pulizia form modal');
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => alert.remove());
        segnalazioneForm.reset();
    });
});

// Funzione per inviare la segnalazione
function inviaSegnalazione() {
    if (!validaCampi()) {
        console.log('Validazione campi fallita');
        return;
    }

    const idAnnuncio = document.getElementById('idAnnuncio').value;
    const idSegnalatore = document.getElementById('idSegnalatore').value;
    const motivazione = document.getElementById('motivazione').value;

    console.log('Dati segnalazione:', { idAnnuncio, idSegnalatore, motivazione });

    const pulsanteInvio = document.querySelector('#segnalazioneModal .btn-primary');
    pulsanteInvio.disabled = true;
    pulsanteInvio.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Invio in corso...';

    const datiForm = new URLSearchParams();
    datiForm.append('id_annuncio', idAnnuncio);
    datiForm.append('id_segnalatore', idSegnalatore);
    datiForm.append('motivazione', motivazione);

    console.log('URL richiesta:', `/dettagli-annuncio_h/${idAnnuncio}`);
    console.log('Dati form:', datiForm.toString());

    fetch(`/dettagli-annuncio_h/${idAnnuncio}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-Requested-With': 'XMLHttpRequest'
        },
        body: datiForm
    })
    .then(response => {
        console.log('Status risposta:', response.status);
        console.log('Headers risposta:', [...response.headers.entries()]);

        // Verifica se la risposta è ok
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        // Verifica il Content-Type
        const contentType = response.headers.get('content-type');
        console.log('Content-Type risposta:', contentType);

        if (!contentType || !contentType.includes('application/json')) {
            // Se non è JSON, leggi come testo e logga
            return response.text().then(text => {
                console.log('Risposta non-JSON:', text);
                throw new TypeError("La risposta non è in formato JSON");
            });
        }

        return response.json();
    })
    .then(data => {
        console.log('Risposta JSON:', data);
        if (data.success) {
            mostraSuccesso('Segnalazione inviata con successo');
            document.getElementById('segnalazioneForm').reset();
            setTimeout(() => {
                const modal = bootstrap.Modal.getInstance(document.getElementById('segnalazioneModal'));
                modal.hide();
            }, 1500);
        } else {
            throw new Error(data.message || 'Errore durante l\'invio della segnalazione');
        }
    })
    .catch(error => {
        console.error('Errore dettagliato:', error);
        mostraErrore(error.message || 'Si è verificato un errore durante l\'invio della segnalazione');
    })
    .finally(() => {
        console.log('Richiesta completata');
        pulsanteInvio.disabled = false;
        pulsanteInvio.innerHTML = 'Invia';
    });
}