
    document.addEventListener('DOMContentLoaded', function () {
        const passwordField = document.getElementById('password');
        const togglePasswordButton = document.getElementById('togglePassword');

        togglePasswordButton.addEventListener('click', function () {
            // Cambia il tipo di input tra 'text' e 'password'
            const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordField.setAttribute('type', type);

            // Cambia l'icona o il testo del pulsante
            togglePasswordButton.textContent = type === 'password' ? '👁️' : '🙈';
        });
    });

